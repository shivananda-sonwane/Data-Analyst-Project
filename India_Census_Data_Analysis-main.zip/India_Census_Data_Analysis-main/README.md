
# India_Census_Data_Analysis

The dataset consists of two file namely:-

1. Data1

2. Data2


The data is downloaded from different websites so might me there can be some error in data.
I have used Statistics and SQL for finding the various insites of data which are as follows :- 

i) Total number of rows in dataset. 

ii) Dataset for Jharkhand and Bihar(using the where condition). 

iii) Total population of India. 

iv) Average growth rate of each state. 

v) Average Gender ration of each state. 

vi) Average Literacy rate of each state. 

vii) Top 3 state showing highest growth ratio. 

viii) Bottom 3 state showing lowest Gender ratio. 

ix) Top and bottom 3 states in Literacy state. 

x) Total males and females population State wise. 

xi) Total Literacy rate. 

xii) Population in previous census.

